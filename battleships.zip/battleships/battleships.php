<?php


abstract class Ship {
    // Abstract battleship class containing attack and is_hit methods
    
    // damage function is required to be defined for any concrete class based on 
    // the abstract Ship class. This value is used in the calculation of attack 
    // method results.
    abstract function damage();
    
    // defense function is required to be defined for any concrete class based on 
    // the abstract Ship class. This value is used in the calculation of attack 
    // method results.
    abstract function defense();
    
    // health variable is initially set to 100. On reaching 0, the ship is considered
    // destroyed
    private $health = 100;
    
    // destroyed boolean variable. Attacks against a ship with a true destroyed 
    // value will do nothing    
    private $destroyed = false;
    
    public $BlackbeardMultiplier = false;
    
    public $PopeyeMultiplier = false;
    
    public function recruit($sailor) {
        // A public method to allow for adding special pirates to the crew. In the event 
        // that the pirate is not a desirable candidate, a rejection message is printed.
        if ($sailor == "Blackbeard") {
            $this->BlackbeardMultiplier = true;
            echo "welcom aboard Blackbeard!";
            return 0;
        } elseif ($sailor == "Popeye") {
            $this->PopeyeMultiplier = true;
            echo "Welcome aboard Popeye!";
            return 0;
        } else {
            echo "            Dear " . $sailor . ", \n            Thank you for your application for the 
            role of sailor at " . get_class($this) . ". We really appreciate your 
            interest in joining our company, and we’re pleased that you decided to 
            invest time and effort in applying for one of our positions. \n 
            We carefully reviewed a large number of applications; unfortunately, 
            at this time we won’t be able to invite you to the next stage of the 
            hiring process. Though your resume was impressive, we have decided 
            to move forward with a candidate whose qualifications are better suited 
            to this particular role. \n
            We wish you much success in your future endeavors. \n
            Once again, thank you for your interest in working for our company. \n
            Sincerely, \n
            Ship's Captain \n";
            return -1;
        }
    }
    
    public function attacks($enemy) {
        // A public method to initiate the reduction of the health of an enemy ship.
        // several checks are first undertaken to ensure that the ship exists, 
        // that the attack is not self-directed, and that the ship you are attempting to 
        // initiatee an attack from has not been destroyed.        

        if ($this->destroyed) {
            
            echo "This ship has been destroyed, and so cannot perform an attack! \n";
            
            return -1;
            
        } elseif (!(isset($enemy)) || $enemy->destroyed) {

            echo "The ship you are trying to attack does not exist... \n";
            
            return -1;

        } elseif ($enemy == $this) {            

            echo "You cannot fire on your own ship! \n";            
            
            return -1;

        } else {        
            // Once checks are complete, random numbers accuracy and luck are generated.
            // accuracy has value 0 with probability 1/4, which condition causes the 
            // shot to 'miss' and inflict no damage. Luck has value 9 with probability 1/10,
            // which condition causes the shot to be 'lucky' and cause triple damage.
            // Attacker damage and enemy defense values are then used to calculate the
            // total damage of each shot, after which the damage is inflicted with 
            // the is-hit method of the enemy ship.

            $accuracy = rand(0, 3);
            $luck = rand(0, 9);
            $damage = $this->damage();
            $defense = $enemy->defense();
            
            // attack and defense multipliers due to crew members are used to 
            // modify attack result.
            if ($this->BlackbeardMultiplier) {
                $damage *= 1.1;
            }
            
            if ($enemy->PopeyeMultiplier) {
                $defense *= 1.1;
            }
       
            if ($accuracy != 0) {

                if ($luck == 9) {

                    $points = 3*$damage*(25/$defense);
                    echo 'Lucky hit! The ' . get_class($this) . ' inflicts ';
                    echo $points . ' damage against the ' . get_class($enemy) . "\n";
                    return $enemy->is_hit($points);

                } else {

                    $points = $damage*(25/$defense);                
                    echo 'Standard hit. The ' . get_class($this) . ' inflicts ';
                    echo $points . ' damage against the ' . get_class($enemy) . "\n";
                    return $enemy->is_hit($points);

                }
            }
        }
    }
    
    public function is_hit($points) {
        // reduces the health points available to the ship by `points`. The health 
        // of the ship is then checked, and if found to be non-positive the 
        // `destroyed` variable is updated to true, preventing further attacks by 
        // or against this ship.

        $this->health -= $points;

        if ($this->health <= 0) {
            echo 'The ' . get_class($this) . ' sinks' . "\n";
            $this->destroyed = true;
            return 1;
        } else {
            return 0;
        }

                    }
    public function get_health() {
        // returns the health of the ship, primarily used for unit testing.
        if ($this->destroyed) {
            return 0;
        } else {
            return $this->health;
        }
    }
}

class Destroyer extends Ship {
    // Concrete Destroyer class, medium damage and high defense

    function damage() {
        return 15;
    }

    function defense() {
        return 50;
    }
}

class Carrier extends Ship {
    // Concrete Carrier class, high damage and medium defense

    function damage() {
        return 30;
    }

    function defense() {
        return 30;
    }
}

class Trawler extends Ship {
    // Concrete Trawler class, no damage and minimal defense

    function damage() {
        return 0;
    }

    function defense() {
        return 5;
    }
}



