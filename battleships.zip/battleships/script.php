<?php
include 'battleships.php';

$Doombringer = new Destroyer();

$Valkyrie = new Carrier();

while (true) {
	if ($Doombringer->attacks($Valkyrie) == 1) {
		break;
	}
	
	if ($Valkyrie->attacks($Doombringer) == 1) {
		break;
	}
	
}
?>
